﻿using System;
class Program
{
   static void Main()
    { 
    int sum = 0;
    int count = 10;
    int currentNumber = 1;
for (int i = 0; i < count; i++);
{
    sum += currentNumber;
    currentNumber+= 2;
}
Console.WriteLine(sum);
        }
}