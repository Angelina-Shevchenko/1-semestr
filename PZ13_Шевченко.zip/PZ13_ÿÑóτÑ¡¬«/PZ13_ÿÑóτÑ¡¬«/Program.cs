﻿using System;
class Program
{
    static void Main()
    { 
        int[] numbers = { 10, 25, 30, 45, 50, 70, 80, 100, 40, 20, 15 };
    
    foreach (int number in numbers)
            {
        if(number > 20 && number< 50)
             {
                Console.WriteLine(number);
         }
        }
     }
    }
