﻿// 01_01.cs - Первая программ
using static System. Console;
class HElloUser
{
    static void Main()
    { 
    
            string name;
            WriteLine("Введите Ваше имя:");
            name = ReadLine();
        WriteLine("Приветствую Вас, " + name + "!");
        WriteLine("Для завершения сеанса нажмите ENTER.");
        ReadLine();
        

        }
    }

