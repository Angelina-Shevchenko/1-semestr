﻿using System;
namespace program_2
{
    class Program

    {
        static void Main(string[] args)

        {
            string name;
            System.Console.WriteLine("Введите Ваше имя:");
            name = System.Console.ReadLine();
            System.Console.ReadLine();
            System.Console.WriteLine("Приветствую Вас, " + name + "!");

        }
    }
}
