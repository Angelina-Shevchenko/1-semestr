﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        
        string fileName = "numbers.txt";

        
        int[] numbers = new int[500];
        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = i + 1;
        }

       
        File.WriteAllText(fileName, string.Join(",", numbers));

        Console.WriteLine($"Числа от 1 до 500 записаны в файл {fileName}.");
    }
}