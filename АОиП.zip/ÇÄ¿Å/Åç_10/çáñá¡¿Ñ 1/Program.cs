﻿using System;

namespace ПЗ_9_з1
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            int min = int.MaxValue; 

            do
            {
                Console.Write("Введите целое число (0 для завершения): ");
                number = Convert.ToInt32(Console.ReadLine());

                if (number != 0) 
                {
                    if (number < min) 
                    {
                        min = number; 
                    }
                }

            } while (number != 0); 

            if (min == int.MaxValue)
            {
                Console.WriteLine("Последовательность была пустой.");
            }
            else
            {
                Console.WriteLine($"Минимальное число в последовательности: {min}");
            }

           
            Console.ReadKey();
        }
    }
}
