﻿using System;

class Program
{
    static void Main()
    {
        string octalNumber = Console.ReadLine();
        ulong decimalNumber = Convert.ToUInt64(octalNumber, 8);
        Console.WriteLine(decimalNumber);
    }
}