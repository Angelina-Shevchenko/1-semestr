﻿using System;

class Program
{
    static void Main()
    {
        double A = double.Parse(Console.ReadLine());
        double C = double.Parse(Console.ReadLine());

        for (double x = -10; x <= 10; x += 0.1)
        {
            double y = A * x * x + C;
            Console.WriteLine($"x: {x}, y: {y}");
        }
    }
}