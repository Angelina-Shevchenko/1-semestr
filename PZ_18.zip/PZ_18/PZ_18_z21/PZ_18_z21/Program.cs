﻿using System;

class Program
{
    static void Main()
    {
        ulong number = ulong.Parse(Console.ReadLine());

        int countOfOnes = Convert.ToString((long)number, 2).Count(c => c == '1');

        bool isEvenCountOfOnes = countOfOnes % 2 == 0;

        Console.WriteLine(isEvenCountOfOnes ? "Четное" : "Нечетное");
    }
}