﻿using System;

class Program
{
    static void Main()
    {
        int X = int.Parse(Console.ReadLine());
        int Y = int.Parse(Console.ReadLine());

        int result = Multiply(X, Y);
        Console.WriteLine(result);
    }

    static int Multiply(int X, int Y)
    {
        int result = 0;
        for (int i = 0; i < Y; i++)
            result += X;
        return result;
    }
}