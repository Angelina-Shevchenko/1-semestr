﻿using System;

class Program
{
    static void Main()
    {
        double radius = double.Parse(Console.ReadLine());
        int iterations = int.Parse(Console.ReadLine());
        Random rand = new Random();
        int insideSphere = 0;

        for (int i = 0; i < iterations; i++)
        {
            double x = rand.NextDouble() * radius * 2 - radius;
            double y = rand.NextDouble() * radius * 2 - radius;
            double z = rand.NextDouble() * radius * 2 - radius;

            if (x * x + y * y + z * z <= radius * radius)
                insideSphere++;
        }

        double volume = (double)insideSphere / iterations * Math.Pow(radius * 2, 3;
        Console.WriteLine($"Объем: {volume}");
    }
}