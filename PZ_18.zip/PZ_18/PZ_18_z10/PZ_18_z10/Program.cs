﻿using System;

class Program
{
    static void Main()
    {
        int diameter = int.Parse(Console.ReadLine());
        double radius = diameter / 2.0;

        for (double y = -radius; y <= radius; y++)
        {
            for (double x = -radius; x <= radius; x++)
            {
                if (Math.Round(Math.Sqrt(x * x + y * y)) == radius)
                    Console.Write("*");
                else
                    Console.Write(" ");
            }
            Console.WriteLine();
        }
    }
}