﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int digitCount = int.Parse(Console.ReadLine());
        int sumDigits = int.Parse(Console.ReadLine());

        List<int> results = new List<int>();

        FindNumbers(digitCount, sumDigits, "", results);

        foreach (var number in results)
            Console.WriteLine(number);
    }

    static void FindNumbers(int digitsLeft, int sumLeft, string current, List<int> results)
    {
        if (digitsLeft == 0 && sumLeft == 0)
            results.Add(int.Parse(current));

        if (digitsLeft <= 0 || sumLeft < 0)
            return;

        for (int i = (current.Length == 0 ? 1 : 0); i <= 9; i++)
            FindNumbers(digitsLeft - 1, sumLeft - i, current + i, results);
    }
}