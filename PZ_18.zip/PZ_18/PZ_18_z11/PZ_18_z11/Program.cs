﻿using System;

class Program
{
    static void Main()
    {
        double a = double.Parse(Console.ReadLine()); 
        double b = double.Parse(Console.ReadLine()); 
        double c = double.Parse(Console.ReadLine()); 
        int iterations = int.Parse(Console.ReadLine());

        Random rand = new Random();
        int insideCurve = 0;

        for (int i = 0; i < iterations; i++)
        {
            double x = rand.NextDouble() * 10; 
            double y = rand.NextDouble() * 10; 

            if (y <= a * x * x + b * x + c && y >= 0)
                insideCurve++;
        }

        double area = (double)insideCurve / iterations * 10 * 10; 
        Console.WriteLine($"Площадь: {area}");
    }
}