﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите количество цифр в номере билета (четное число): ");
        int digits = Convert.ToInt32(Console.ReadLine());

        if (digits % 2 != 0)
        {
            Console.WriteLine("Количество цифр должно быть четным.");
            return;
        }

        int halfDigits = digits / 2;
        int maxSum = halfDigits * 9; 
        long[] countWays = new long[maxSum + 1];

        
        for (int i = 0; i < Math.Pow(10, halfDigits); i++)
        {
            int sum = 0;
            int temp = i;

            
            for (int j = 0; j < halfDigits; j++)
            {
                sum += temp % 10;
                temp /= 10;
            }

            countWays[sum]++;
        }

        long luckyTicketsCount = 0;

        
        for (int sum = 0; sum <= maxSum; sum++)
        {
            luckyTicketsCount += countWays[sum] * countWays[sum];
        }

        Console.WriteLine($"Количество счастливых билетов с {digits} цифрами: {luckyTicketsCount}");
    }
}