﻿using System;

class Program
{
    static void Main(string[] args)
    {
        
        Console.Write("Введите начало интервала (a): ");
        double a = Convert.ToDouble(Console.ReadLine()); 

        Console.Write("Введите конец интервала (b): ");
        double b = Convert.ToDouble(Console.ReadLine()); 

        Console.Write("Введите шаг изменения аргумента (h): ");
        double h = Convert.ToDouble(Console.ReadLine());

        double maxY = double.MinValue;
        double correspondingX = a; 

        
        for (double x = a; x <= b; x += h)
        {
            double y = 5 * Math.Cos(3 * x); 

            
            if (y > maxY)
            {
                maxY = y; 
                correspondingX = x; 
            }
        }

        
        Console.WriteLine($"Максимальное значение функции: y = {maxY}");
        Console.WriteLine($"Соответствующее значение аргумента: x = {correspondingX}");
    }
}