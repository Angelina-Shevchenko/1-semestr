﻿using System;

class Program
{
    static void Main()
    {
        double A = double.Parse(Console.ReadLine());
        double omega = double.Parse(Console.ReadLine());
        double alpha = double.Parse(Console.ReadLine());
        int iterations = int.Parse(Console.ReadLine());

        Random rand = new Random();
        int insideCurve = 0;

        for (int i = 0; i < iterations; i++)
        {
            double x = rand.NextDouble() * Math.PI; 
            double y = rand.NextDouble() * A; 

            if (y <= A * Math.Sin(omega * x + alpha))
                insideCurve++;
        }

        double area = (double)insideCurve / iterations * Math.PI * A; 
        Console.WriteLine($"Площадь: {area}");
    }
}