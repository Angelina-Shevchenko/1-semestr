﻿using System;

class Program
{
    static void Main()
    {
        double a = double.Parse(Console.ReadLine()); 
        double b = double.Parse(Console.ReadLine()); 
        double h = double.Parse(Console.ReadLine()); 

        double area = CalculateArea(a, b, h);

        Console.WriteLine($"Площадь под кривой: {area}");
    }

    static double CalculateArea(double a, double b, double h)
    {
        double area = 0.0;

        for (double x = a; x < b; x += h)
        {
            double y1 = Function(x);
            double y2 = Function(x + h);

            area += (y1 + y2) * h / 2;
        }

        return area;
    }

    static double Function(double x)
    {
        return 3 * x * x - 2 * x + 5;
    }
}