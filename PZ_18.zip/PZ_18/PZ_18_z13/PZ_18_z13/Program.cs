﻿using System;

class Program
{
    static void Main()
    {
        double A = double.Parse(Console.ReadLine());
        double tau = double.Parse(Console.ReadLine());

        for (double x = 0; x <= 10; x += 0.1)
        {
            double y = A * Math.Exp(-x / tau);
            Console.WriteLine($"x: {x}, y: {y}");
        }
    }
}