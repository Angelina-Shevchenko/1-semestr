﻿using System;

class Program
{
    static void Main()
    {
        double radius = double.Parse(Console.ReadLine());
        int iterations = int.Parse(Console.ReadLine());

        Random rand = new Random();
        int insideCircle = 0;

        for (int i = 0; i < iterations; i++)
        {
            double x = rand.NextDouble() * radius * 2 - radius;
            double y = rand.NextDouble() * radius * 2 - radius;

            if (x * x + y * y <= radius * radius)
                insideCircle++;
        }

        double area = (double)insideCircle / iterations * (radius * 2) * (radius * 2); 
        Console.WriteLine($"Площадь окружности: {area}");
    }
}