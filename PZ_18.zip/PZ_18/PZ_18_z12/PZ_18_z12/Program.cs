﻿using System;

class Program
{
    static void Main()
    {
        double precision = double.Parse(Console.ReadLine());
        double pi = 0;
        int n = 0;

        while (true)
        {
            double term = (n % 2 == 0 ? 1 : -1) * (4.0 / (2 * n + 1));
            pi += term;
            if (Math.Abs(term) < precision)
                break;
            n++;
        }

        Console.WriteLine($"Число членов: {n}, π: {pi}");
    }
}