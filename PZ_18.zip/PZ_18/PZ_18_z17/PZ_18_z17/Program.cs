﻿using System;

class Program
{
    static void Main()
    {
        int d1 = int.Parse(Console.ReadLine()); 
        int d2 = d1 * 2; 

        for (int i = -d1 / 2; i <= d1 / 2; i++)
        {
            for (int j = -d2 / 2; j <= d2 / 2; j++)
            {
                if (Math.Abs(i) + Math.Abs(j) == d1 / 2)
                    Console.Write("*");
                else
                    Console.Write(" ");
            }
            Console.WriteLine();
        }
    }
}