﻿using System;

class Program
{
    static void Main(string[] args)
    {
        
        double a = 0; 
        double b = 10; 
        double h = 0.1; 

        
        double area = CalculateArea(a, b, h);

        
        Console.WriteLine($"Площадь под кривой на интервале [{a}, {b}] с шагом {h}: {area}");
    }

    static double CalculateArea(double a, double b, double h)
    {
        double area = 0.0;

        for (double x = a; x < b; x += h)
        {
            
            double y1 = Function(x);
            double y2 = Function(x + h);

            
            area += (y1 + y2) * h / 2;
        }

        return area;
    }

    static double Function(double x)
    {
        return 2 * x + 2 * Math.Sin(x / 3);
    }
}