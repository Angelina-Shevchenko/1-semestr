﻿using System;

class Program
{
    static void Main(string[] args)
    {
        
        Console.Write("Введите число (unsigned long): ");

        
        if (ulong.TryParse(Console.ReadLine(), out ulong number))
        {
            
            string hexRepresentation = number.ToString("X");

            
            Console.WriteLine($"Шестнадцатеричное представление: {hexRepresentation}");
        }
        else
        {
            Console.WriteLine("Ошибка: Введите корректное число.");
        }
    }
}