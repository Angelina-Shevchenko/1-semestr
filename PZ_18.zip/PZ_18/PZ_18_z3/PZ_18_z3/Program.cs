﻿using System;

class Program
{
    static void Main(string[] args)
    {
        
        Console.Write("Введите начало интервала (a): ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите конец интервала (b): ");
        double b = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите шаг (h): ");
        double h = Convert.ToDouble(Console.ReadLine());

        
        double area = CalculateArea(a, b, h);

        
        Console.WriteLine($"Площадь под кривой y = 7*sin(x) на интервале [{a}, {b}] равна: {area}");
    }

    static double CalculateArea(double a, double b, double h)
    {
        double area = 0.0;

        
        for (double x = a; x < b; x += h)
        {
            double y1 = 7 * Math.Sin(x); 
            double y2 = 7 * Math.Sin(x + h); 

            
            area += (y1 + y2) * h / 2;
        }

        return area;
    }
}