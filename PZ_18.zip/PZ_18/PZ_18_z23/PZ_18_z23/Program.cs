﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int countOfOnes = int.Parse(Console.ReadLine());
        List<ulong> results = new List<ulong>();

        GenerateNumbers(countOfOnes, "", results);

        foreach (var number in results)
            Console.WriteLine(number);
    }

    static void GenerateNumbers(int onesLeft, string current, List<ulong> results)
    {
        if (onesLeft == 0)
        {
            results.Add(Convert.ToUInt64(current, 2));
            return;
        }

        GenerateNumbers(onesLeft - 1, current + "1", results);

        if (current.Length > 0)
            GenerateNumbers(onesLeft, current + "0", results);
    }
}