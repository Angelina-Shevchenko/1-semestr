﻿using System;

class Program
{
    static void Main()
    {
        
        double a = double.Parse(Console.ReadLine());
        double b = double.Parse(Console.ReadLine());
        double c = double.Parse(Console.ReadLine());
        double d = double.Parse(Console.ReadLine());

        // Начальное приближение и точность
        double initialGuess = double.Parse(Console.ReadLine());
        double precision = double.Parse(Console.ReadLine());

        double root = NewtonRaphson(a, b, c, d, initialGuess, precision);

        Console.WriteLine($"Корень уравнения: {root}");
    }

    static double NewtonRaphson(double a, double b, double c, double d, double guess, double precision)
    {
        while (true)
        {
            double fValue = a * guess * guess * guess + b * guess * guess + c * guess + d;
            double fDerivativeValue = 3 * a * guess * guess + 2 * b * guess + c;

            if (Math.Abs(fValue) < precision)
                return guess;

            guess -= fValue / fDerivativeValue;
        }
    }
}