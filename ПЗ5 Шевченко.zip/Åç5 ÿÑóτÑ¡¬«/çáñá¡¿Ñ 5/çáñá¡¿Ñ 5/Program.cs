﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x = 2;
            double y = 5;
            double z = (x - y) / (1 + x * y);
            Console.WriteLine(z);
            Console.ReadKey();
        }
    }
}
