﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = Convert.ToInt32(Console.ReadLine());
            int o = Convert.ToInt32(Console.ReadLine());
            if (i >= o)
            {
                Console.WriteLine(i);
            }
            else
            {
                Console.WriteLine(o);
                Console.ReadKey();
            }
            Console.ReadLine();
        }
    }
}
