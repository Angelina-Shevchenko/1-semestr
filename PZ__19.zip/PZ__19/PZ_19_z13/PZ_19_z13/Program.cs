﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Polygon
{
    public int VerticesCount { get; set; }
    public double Area { get; set; }
    public double Perimeter { get; set; }

    public Polygon(int verticesCount, double area, double perimeter)
    {
        VerticesCount = verticesCount;
        Area = area;
        Perimeter = perimeter;
    }
}

public class PolygonCollection
{
    private List<Polygon> polygons = new List<Polygon>();

    public void AddPolygon(Polygon polygon)
    {
        polygons.Add(polygon);
    }

    public List<Polygon> GetPolygonsSortedByArea()
    {
        return polygons.OrderBy(p => p.Area).ToList();
    }

    public List<Polygon> GetPolygonsSortedByPerimeter()
    {
        return polygons.OrderBy(p => p.Perimeter).ToList();
    }

    public (double totalArea, double totalPerimeter) CalculateTotalAreaAndPerimeter()
    {
        double totalArea = polygons.Sum(p => p.Area);
        double totalPerimeter = polygons.Sum(p => p.Perimeter);
        return (totalArea, totalPerimeter);
    }
}