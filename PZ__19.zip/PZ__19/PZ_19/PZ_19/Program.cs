﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Point3D
{
    public double X { get; }
    public double Y { get; }
    public double Z { get; }

    public Point3D(double x, double y, double z)
    {
        X = x;
        Y = y;
        Z = z;
    }

    public double DistanceFromOrigin() => Math.Sqrt(X * X + Y * Y + Z * Z);
}

class Program
{
    static void Main()
    {
        List<Point3D> points = new List<Point3D>
        {
            new Point3D(1, 2, 3),
            new Point3D(4, 5, 6),
            new Point3D(-1, -2, -1),
            new Point3D(0, 0, 0)
        };

        var sortedPoints = points.OrderBy(p => p.DistanceFromOrigin()).ToList();
        double maxDistance = sortedPoints.Max(p => p.DistanceFromOrigin());
        double minDistance = sortedPoints.Min(p => p.DistanceFromOrigin());

        Console.WriteLine("Сортированные точки по удалению от центра:");
        foreach (var point in sortedPoints)
        {
            Console.WriteLine($"({point.X}, {point.Y}, {point.Z}) - Расстояние: {point.DistanceFromOrigin()}");
        }

        Console.WriteLine($"Максимальное расстояние: {maxDistance}");
        Console.WriteLine($"Минимальное расстояние: {minDistance}");
    }
}