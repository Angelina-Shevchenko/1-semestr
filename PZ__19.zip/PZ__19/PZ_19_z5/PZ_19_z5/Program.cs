﻿using System;
using System.Collections.Generic;
using System.Linq;

public class ComplexNumber
{
    public double Real { get; }
    public double Imaginary { get; }

    public ComplexNumber(double real, double imaginary)
    {
        Real = real;
        Imaginary = imaginary;
    }

    public double Modulus() => Math.Sqrt(Real * Real + Imaginary * Imaginary);
}

class Program
{
    static void Main()
    {
        List<ComplexNumber> numbers = new List<ComplexNumber>
        {
            new ComplexNumber(1, 2),
            new ComplexNumber(3, 4),
            new ComplexNumber(5, -6)
        };

        var sortedNumbers = numbers.OrderBy(n => n.Modulus()).ToList();

        Console.WriteLine("Сортированные комплексные числа по модулю:");
        foreach (var number in sortedNumbers)
        {
            Console.WriteLine($"{number.Real} + {number.Imaginary}i");
        }

        var product = numbers.Aggregate(new ComplexNumber(1, 0), (acc, n) =>
            new ComplexNumber(acc.Real * n.Real - acc.Imaginary * n.Imaginary,
                              acc.Real * n.Imaginary + acc.Imaginary * n.Real));

        Console.WriteLine($"Произведение всех чисел: {product.Real} + {product.Imaginary}i");
    }
}