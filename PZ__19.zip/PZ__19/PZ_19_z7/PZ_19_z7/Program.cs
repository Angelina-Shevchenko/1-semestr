﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Rectangle
{
    public double Width { get; }
    public double Height { get; }

    public Rectangle(double width, double height)
    {
        Width = width;
        Height = height;
    }

    public double Area() => Width * Height;

    public string Orientation() => Width > Height ? "Горизонтальная" : "Вертикальная";
}

class Program
{
    static void Main()
    {
        List<Rectangle> rectangles = new List<Rectangle>
        {
            new Rectangle(4, 5),
            new Rectangle(6, 3),
            new Rectangle(8, 8)
        };

        var sortedRectangles = rectangles.OrderBy(r => r.Area()).ToList();

        foreach (var rectangle in sortedRectangles)
        {
            Console.WriteLine($"Площадь: {rectangle.Area()}, Ориентация: {rectangle.Orientation()}");
        }
    }
}