﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Triangle
{
    public double SideA { get; set; }
    public double SideB { get; set; }
    public double SideC { get; set; }

    public Triangle(double sideA, double sideB, double sideC)
    {
        SideA = sideA;
        SideB = sideB;
        SideC = sideC;
    }

    public double Area()
    {
        double s = (SideA + SideB + SideC) / 2;
        return Math.Sqrt(s * (s - SideA) * (s - SideB) * (s - SideC));
    }
}

public class TriangleCollection
{
    private List<Triangle> triangles = new List<Triangle>();

    public void AddTriangle(Triangle triangle)
    {
        triangles.Add(triangle);
    }

    public List<Triangle> GetTrianglesSortedByArea()
    {
        return triangles.OrderBy(t => t.Area()).ToList();
    }

    public List<List<Triangle>> FindSimilarTriangles()
    {
        var groups = triangles.GroupBy(t => new { t.SideA, t.SideB, t.SideC })
                              .Where(g => g.Count() > 1)
                              .Select(g => g.ToList())
                              .ToList();
        return groups;
    }
}