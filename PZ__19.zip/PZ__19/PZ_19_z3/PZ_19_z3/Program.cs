﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<Point2D> points = new List<Point2D>
        {
            new Point2D(0, 0),
            new Point2D(1, 1),
            new Point2D(2, 0),
            new Point2D(1, -1)
        };

        // Простой вывод точек с индексами
        for (int i = 0; i < points.Count; i++)
        {
            Console.WriteLine($"Точка {i}: ({points[i].X}, {points[i].Y})");
        }
    }
}