﻿using System;
using System.Collections.Generic;

public class ColoredPoint
{
    public double X { get; }
    public double Y { get; }
    public string Color { get; }

    public ColoredPoint(double x, double y, string color)
    {
        X = x;
        Y = y;
        Color = color;
    }
}

class Program
{
    static void Main()
    {
        List<ColoredPoint> points = new List<ColoredPoint>
        {
            new ColoredPoint(0, 0, "Red"),
            new ColoredPoint(1, 1, "Red"),
            new ColoredPoint(2, 0, "Blue"),
            new ColoredPoint(3, -1, "Blue")
        };

        var groupedByColor = points.GroupBy(p => p.Color);

        foreach (var group in groupedByColor)
        {
            Console.WriteLine($"Цвет: {group.Key}, Длина: {CalculateLength(group.ToList())}");
        }
    }

    static double CalculateLength(List<ColoredPoint> points)
    {
        double length = 0;

        for (int i = 0; i < points.Count - 1; i++)
        {
            length += Math.Sqrt(Math.Pow(points[i + 1].X - points[i].X, 2) +
                                 Math.Pow(points[i + 1].Y - points[i].Y, 2));
        }

        return length;
    }
}