﻿using System;
using System.Collections.Generic;

public class Point2D
{
    public double X { get; }
    public double Y { get; }

    public Point2D(double x, double y)
    {
        X = x;
        Y = y;
    }
}

class Program
{
    static void Main()
    {
        List<Point2D> points = new List<Point2D>
       {
           new Point2D(0, 0),
           new Point2D(1, 1),
           new Point2D(3, 3),
           new Point2D(5, -1)
       };

        
        for (int i = 0; i < points.Count; i++)
        {
            Console.WriteLine($"Точка {i}: ({points[i].X}, {points[i].Y})");
        }

        
        double minLength = Double.MaxValue;
        int minIndexA = -1;
        int minIndexB = -1;

        for (int i = 0; i < points.Count - 1; i++)
        {
            for (int j = i + 1; j < points.Count; j++)
            {
                double length = Distance(points[i], points[j]);
                if (length < minLength)
                {
                    minLength = length;
                    minIndexA = i;
                    minIndexB = j;
                }
            }
        }

        Console.WriteLine($"Сегмент наименьшей длины между точками {minIndexA} и {minIndexB} с длиной: {minLength}");
    }

    static double Distance(Point2D a, Point2D b)
    {
        return Math.Sqrt(Math.Pow(b.X - a.X, 2) + Math.Pow(b.Y - a.Y, 2));
    }
}