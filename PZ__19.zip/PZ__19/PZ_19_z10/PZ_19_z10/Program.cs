﻿using System;
using System.Collections.Generic;
using System.Drawing;

public class Rectangle
{
    public double X { get; }
    public double Y { get; }
    public double Width { get; }
    public double Height { get; }

    public Rectangle(double x, double y, double width, double height)
    {
        X = x;
        Y = y;
        Width = width;
        Height = height;
    }

    public bool Contains(Point point) =>
        point.X >= X && point.X <= X + Width && point.Y >= Y && point.Y <= Y + Height;

    public static Rectangle GetBoundingRectangle(List<Rectangle> rectangles)
    {
        if (rectangles.Count == 0) return null;

        var minX = rectangles.Min(r => r.X);
        var minY = rectangles.Min(r => r.Y);
        var maxX = rectangles.Max(r => r.X + r.Width);
        var maxY = rectangles.Max(r => r.Y + r.Height);

        return new Rectangle(minX, minY, maxX - minX, maxY - minY);
    }
}

class Program
{
    static void Main()
    {
        List<Rectangle> rectangles = new List<Rectangle>
       {
           new Rectangle(0, 0, 4, 4),
           new Rectangle(5, 5, 3, 3),
           new Rectangle(3, -1, 6, 4)
       };

        var boundingRectangle = Rectangle.GetBoundingRectangle(rectangles);

        if (boundingRectangle != null)