﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Point3D
{
    public double X { get; set; }
    public double Y { get; set; }
    public double Z { get; set; }

    public Point3D(double x, double y, double z)
    {
        X = x;
        Y = y;
        Z = z;
    }
}

public class Point3DCollection
{
    private List<Point3D> points = new List<Point3D>();

    public void AddPoint(Point3D point)
    {
        points.Add(point);
    }

    public List<Point3D> SortPoints(Func<Point3D, object> sortBy)
    {
        {
            return points.OrderBy(sortBy).ToList();
        }
    }
}
