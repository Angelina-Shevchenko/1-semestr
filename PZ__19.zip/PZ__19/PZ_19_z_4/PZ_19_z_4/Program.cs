﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<Point2D> points = new List<Point2D>
        {
            new Point2D(0, 0),
            new Point2D(1, 1),
            new Point2D(2, 2),
            new Point2D(3, 3)
        };

        for (int i = 0; i < points.Count; i += 2)
        {
            if (i + 1 < points.Count)
            {
                Console.WriteLine($"Пара: ({points[i].X}, {points[i].Y}) и ({points[i + 1].X}, {points[i + 1].Y})");
            }
        }
    }
}