﻿using System;
using System.Collections.Generic;

public class Point2D
{
    public double X { get; }
    public double Y { get; }

    public Point2D(double x, double y)
    {
        X = x;
        Y = y;
    }
}

class Program
{
    static void Main()
    {
        List<Point2D> polygon = new List<Point2D>
        {
            new Point2D(0, 0),
            new Point2D(4, 0),
            new Point2D(4, 3),
            new Point2D(0, 3)
        };

        
        double perimeter = CalculatePerimeter(polygon);
        double area = CalculateArea(polygon);

        Console.WriteLine($"Периметр: {perimeter}");
        Console.WriteLine($"Площадь: {area}");
    }

    static double CalculatePerimeter(List<Point2D> polygon)
    {
        double perimeter = 0;
        for (int i = 0; i < polygon.Count; i++)
        {
            int nextIndex = (i + 1) % polygon.Count;
            perimeter += Distance(polygon[i], polygon[nextIndex]);
        }
        return perimeter;
    }

    static double CalculateArea(List<Point2D> polygon)
    {
        double area = 0;
        for (int i = 0; i < polygon.Count; i++)
        {
            int nextIndex = (i + 1) % polygon.Count;
            area += (polygon[i].X * polygon[nextIndex].Y) - (polygon[nextIndex].X * polygon[i].Y);
        }
        return Math.Abs(area) / 2.0;
    }

    static double Distance(Point2D a, Point2D b)
    {
        return Math.Sqrt(Math.Pow(b.X - a.X, 2) + Math.Pow(b.Y - a.Y, 2));
    }
}