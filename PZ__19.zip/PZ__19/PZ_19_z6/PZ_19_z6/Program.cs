﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Point2D
{
    public double X { get; }
    public double Y { get; }

    public Point2D(double x, double y)
    {
        X = x;
        Y = y;
    }

    public double DistanceFromOrigin() => Math.Sqrt(X * X + Y * Y);
}

class Program
{
    static void Main()
    {
        List<Point2D> points = new List<Point2D>
        {
            new Point2D(1, 1),
            new Point2D(-1, -1),
            new Point2D(1, -1),
            new Point2D(-1, 1)
        };

        var sortedPoints = points.OrderBy(p => p.DistanceFromOrigin()).ToList();

        Console.WriteLine("Сортированные точки:");
        foreach (var point in sortedPoints)
        {
            Console.WriteLine($"({point.X}, {point.Y}) - Расстояние: {point.DistanceFromOrigin()}");
        }

    
    }
}