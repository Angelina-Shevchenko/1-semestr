﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Star
{
    public string Name { get; set; }
    public double Magnitude { get; set; }
    public double Distance { get; set; } // расстояние до Земли в световых годах
    public (double RightAscension, double Declination) Coordinates { get; set; } // координаты на небосклоне

    public Star(string name, double magnitude, double distance, (double, double) coordinates)
    {
        Name = name;
        Magnitude = magnitude;
        Distance = distance;
        Coordinates = coordinates;
    }
}

public class StarCatalog
{
    private List<Star> stars = new List<Star>();

    public void AddStar(Star star)
    {
        stars.Add(star);
    }

    public List<Star> GetStarsSortedByDistance()
    {
        return stars.OrderBy(s => s.Distance).ToList();
    }

    public List<Star> FindStarsByMagnitude(double magnitude)
    {
        return stars.Where(s => s.Magnitude == magnitude).ToList();
    }
}