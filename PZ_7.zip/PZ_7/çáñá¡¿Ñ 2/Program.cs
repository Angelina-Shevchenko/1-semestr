﻿using System;

class Program
{
    static void Main()
    {
        
        string originalString = "Я скоро поеду на научную конференцию в Курск";

       
        int indexKursk = originalString.IndexOf("Курск");
        Console.WriteLine($"Индекс слова 'Курск': {indexKursk}");

       
        string modifiedString = originalString.Replace("в Курск", "").Trim();
        Console.WriteLine($"Строка после удаления 'в Курск': {modifiedString}");

        
        modifiedString = modifiedString.Replace("научную конференцию", "соревнование");
        Console.WriteLine($"Строка после замены: {modifiedString}");

        
        string upperCaseString = modifiedString.ToUpper();
        Console.WriteLine($"Текст в верхнем регистре: {upperCaseString}");
    }
}