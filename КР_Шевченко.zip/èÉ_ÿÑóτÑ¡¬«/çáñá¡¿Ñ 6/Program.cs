﻿using System;

class Program
{
    static void Main()
    {

        int n = int.Parse(Console.ReadLine());

        int result = CountSequences(n, "Подготовка", 0);

        Console.WriteLine(result);
    }

    static int CountSequences(int remainingSteps, string lastCommand, int moveCount)
    {
        if (remainingSteps == 0)
        {
            return 1;
        }

        int totalSequences = 0;

        string[] commands = { "Поиск дефектов", "Движение", "Подготовка", "Ремонт" };

        foreach (var command in commands)
        {
            if (IsValidCommand(lastCommand, command, moveCount))
            {
                int newMoveCount = command == "Движение" ? moveCount + 1 : 0;

                totalSequences += CountSequences(remainingSteps - 1, command, newMoveCount);
            }
        }

        return totalSequences;
    }

    static bool IsValidCommand(string lastCommand, string currentCommand, int moveCount)
    {
        if (currentCommand == "Движение" && moveCount >= 2)
        {
            return false;
        }

        if (currentCommand == "Ремонт" && lastCommand != "Подготовка")
        {
            return false;
        }

        return true;
    }
}