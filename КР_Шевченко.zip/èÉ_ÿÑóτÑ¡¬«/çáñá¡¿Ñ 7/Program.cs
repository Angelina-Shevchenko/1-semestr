﻿using System;

class Program
{
    static void Main()
    {
        long N = long.Parse(Console.ReadLine());

        (long oppositeSeat, char seatType) = GetOppositeSeatAndType(N);

        Console.WriteLine($"{oppositeSeat} {seatType}");
    }

    static (long, char) GetOppositeSeatAndType(long N)
    {
        long compartmentIndex = (N - 1) / 6;
        long seatInCompartment = (N - 1) % 6 + 1;
        long oppositeSeatInCompartment;
        char seatType;

        switch (seatInCompartment)
        {
            case 1:
                oppositeSeatInCompartment = 6;
                seatType = 'W';
                break;
            case 2:
                oppositeSeatInCompartment = 5;
                seatType = 'M';
                break;
            case 3:
                oppositeSeatInCompartment = 4;
                seatType = 'A';
                break;
            case 4:
                oppositeSeatInCompartment = 3;
                seatType = 'A';
                break;
            case 5:
                oppositeSeatInCompartment = 2;
                seatType = 'M';
                break;
            case 6:
                oppositeSeatInCompartment = 1;
                seatType = 'W';
                break;
            default:
                throw new ArgumentOutOfRangeException();
        }
        long oppositeSeat = compartmentIndex * 6 + oppositeSeatInCompartment;

        return (oppositeSeat, seatType);
    }
}