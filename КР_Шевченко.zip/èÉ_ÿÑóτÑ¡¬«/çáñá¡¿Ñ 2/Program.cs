﻿using System;
class з2
{
    static void Main()
    {
        string[] input = Console.ReadLine().Split();
        int A = int.Parse(input[0]); int B = int.Parse(input[1]);
        int count = 0;
        for (int X = A; X <= B; X++)
        {
            string octal = Convert.ToString(X, 8); int length = octal.Length;
            char secondLastDigit = octal[length - 2]; char lastDigit = octal[length - 1];
            char[] newOctal = octal.ToCharArray();
            if (secondLastDigit < '7')
            {
                newOctal[length - 2]++;
            }

            else
            {
                newOctal[length - 2] = '0';
                if (lastDigit % 2 == 0)
                {
                    newOctal[length - 1]++;
                }

                else
                {
                    newOctal[length - 1]--;
                }
            }
            int Y = Convert.ToInt32(new string(newOctal), 8);
            int Oh = X - Y;
            if (Oh > 0)
            {
                count++;
            }
        }
        Console.WriteLine(count);
    }
}