﻿using System;

class Program
{
    static void Main()
    {
        string[] input = Console.ReadLine().Split();
        int t = int.Parse(input[0]);
        int v = int.Parse(input[1]);

        int[] a = Array.ConvertAll(Console.ReadLine().Split(), int.Parse);

        int actualTrips = 0;
        int totalVolume = 0;

        for (int i = 0; i < t; i++)
        {
            actualTrips += (a[i] + v - 1) / v;
            totalVolume += a[i];
        }

        int minimalTrips = (totalVolume + v - 1) / v;

        Console.WriteLine(actualTrips - minimalTrips);
    }
}