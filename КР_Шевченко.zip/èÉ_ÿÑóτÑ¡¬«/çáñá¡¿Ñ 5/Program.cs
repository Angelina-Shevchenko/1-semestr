﻿using System;

class Program
{
    static void Main()
    {
        string[] input = Console.ReadLine().Split();
        int N = int.Parse(input[0]);
        double T = double.Parse(input[1]);

        double[] temperatures = new double[N];

        for (int i = 0; i < N; i++)
        {
            temperatures[i] = double.Parse(Console.ReadLine());
        }

        int minDay = 0;
        double minTemperature = temperatures[0];

        for (int i = 1; i < N; i++)
        {
            if (temperatures[i] < minTemperature)
            {
                minTemperature = temperatures[i];
                minDay = i;
            }
        }
        int countAboveThreshold = 0;

        foreach (double temp in temperatures)
        {
            if (temp > T)
            {
                countAboveThreshold++;
            }
        }
        Console.WriteLine(minDay + 1);
        Console.WriteLine(countAboveThreshold);
    }
}