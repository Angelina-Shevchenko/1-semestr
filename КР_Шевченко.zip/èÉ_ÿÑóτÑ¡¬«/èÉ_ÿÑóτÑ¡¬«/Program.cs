﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        var inputs = Console.ReadLine().Split().Select(int.Parse).ToArray();
        int n = inputs[0];
        int v0 = inputs[1];

        var days = Console.ReadLine().Split().Select(int.Parse).ToArray();

        int res = 0;

        foreach (var v in days)
        {
            if (v > 0)
            {
                res += (int)((v + 3 * v0 / 2.0 - 0.5) / v0);
            }
        }

        Console.WriteLine(res);
    }
}